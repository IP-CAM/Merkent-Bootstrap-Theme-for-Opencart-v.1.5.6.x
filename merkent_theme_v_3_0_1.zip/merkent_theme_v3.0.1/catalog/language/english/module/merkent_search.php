<?php
// Heading
$_['heading_title'] 		= 'Merkent Search';

// Text
$_['text_search'] 		= 'Merkent Search';
$_['text_category'] 		= 'All Categories';
$_['text_sub_category'] = 'Search in subcategories';
$_['text_description'] 	= 'Search in product descriptions';
?>