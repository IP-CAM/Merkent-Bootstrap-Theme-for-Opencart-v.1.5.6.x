<?php
// Heading 
$_['heading_latest']   	 = 'Latest Products';
$_['heading_featured'] 	 = 'Featured Products';
$_['heading_special']  	 = 'Specials Products';
$_['heading_bestseller'] = 'Bestsellers Products';

// Text
$_['text_free']  			= 'Free';
$_['text_reviews']  		= 'Based on %s reviews.';
$_['text_empty']  		= 'There are no %s products to show right now!';
$_['text_message']  		= '<div class="attention">Bootstrap Merkent is required for Products module!</div>';

// Button
$_['button_add_cart']  	= 'Add to <i class="fa fa-shopping-cart"></i>';

?>