<?php
// Heading
$_['heading_title']    		= 'Merkent Search';

// Text
$_['text_module']      		= 'Modules';
$_['text_success']     		= 'Success: You have modified the Merkent Search module!';
$_['text_content_top']   	= 'Content Top';
$_['text_content_bottom']	= 'Content Bottom';
$_['text_column_left']   	= 'Column Left';
$_['text_column_right'] 	= 'Column Right';

// Entry
$_['entry_layout']        	= 'Layout:';
$_['entry_position']     	= 'Position:';
$_['entry_category']			= 'Categories:';
$_['entry_option']			= 'Options:';
$_['entry_status']        	= 'Status:';
$_['entry_sort_order']    	= 'Sort Order:';

// Button
$_['button_save_continue'] = 'Save & Continue';

// Error
$_['error_permission'] 		= 'Warning: You do not have permission to modify the Merkent Search module!';
?>