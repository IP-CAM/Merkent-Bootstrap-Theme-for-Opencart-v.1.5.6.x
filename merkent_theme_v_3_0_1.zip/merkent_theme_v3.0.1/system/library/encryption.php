<?php
final class Encryption {
	public function encrypt($key, $value) {
		$nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);

		return strtr(base64_encode($nonce . sodium_crypto_secretbox($value, $nonce, hash('sha256', $key, true))), '+/=', '-_,');
	}

	public function decrypt($key, $value) {
		$raw_value = base64_decode(strtr($value, '-_,', '+/='));

		$nonce = substr($raw_value, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);

		return trim(sodium_crypto_secretbox_open(substr($raw_value, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), $nonce, hash('sha256', $key, true)));
	}
}
?>