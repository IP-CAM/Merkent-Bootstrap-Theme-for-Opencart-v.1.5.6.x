===============================================
MERKENT THEME FRAMEWORK FOR OPENCART
===============================================
An awesome OpenCart theme and framework built with Twitter Bootstrap.

	- Features a completely responsive design 
	- Developed for OpenCart v1.5.6+
	- Built with Bootstrap v3.2.0
	- Looks and behaves great in all modern browsers
	- Touch enabled image gallery, slideshow and banner
	- Also includes optional dark color scheme
	- Custom Share, Pin It and Tweet buttons
	- Includes complementing Merkent Products module
	- Drag and drop installation, no file editing required

Merkent Products module:

	- Choose between Latest, Featured, Bestseller or Special product types.
	- Display product descriptions with enable/disable option.
	- Display add to cart button with enable/disable option.
	- Show products in a block grid layout or in a Pinterest-like waterfall layout.
	- Save & Continue button in Admin panel.

HISTORY
===============================================
Version 3.0.1 - 7/16/2014
	
	- Bootstrap Products module now Merkent Products
	- Updated uploader (removed need for ajaxupload.js)
	- Changed star rating in product comparison to right class
	- Changed help class from inline-block to block
	- Updated to Font-Awesome 4.1
	- Updated Bootstrap DateTime Picker to v2.3.0
	- Upgraded to Bootstrap v3.2.0
	
Version 3.0.0 - 4/23/2014
	
	- Reduced redundant code by implementing templates
	- Changed jQuery to load ajax.googleapis CDN with local fallback
	- Added touchswipe gestures to image gallery, slideshow and banner
	- Added Font-Awesome 4.0.3
	- Upgraded to Bootstrap v3.1.1
	- Updated to OpenCart v1.5.6+
	- Changed bootstrap_product module to merkent_product

More information on earlier releases can be found at http://merkent.com/releases

INSTALLATION
===============================================
Just unzip and copy/upload the admin, catalog and image folders to the root directory of your OpenCart installation.
That's it! To enable, just change settings in your Admin.

To enable DARK THEME:

	- Open catalog/view/theme/merkent/template/common/header.tpl
	- Replace: <link rel="stylesheet" href="catalog/view/theme/merkent/stylesheet/stylesheet.css">
	- With: <link rel="stylesheet" href="catalog/view/theme/merkent/stylesheet/stylesheet-dark.css">

LICENSE
===============================================
Released under the [GPL license](http://opensource.org/licenses/GPL-3.0).

CREDITS
===============================================
Developed by Justin Ross, justin@merkent.com